package lilhoppr;
import java.util.Scanner;
 class Employee1
{
	private int pan;
	private String name;
	private double income;
	private double tax;
	
	public void input() {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter pan Number:");
		pan=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter Name:");
		name=sc.nextLine();
		System.out.println("Enter taxable Income:");
		income=sc.nextDouble();
	}
	
	public void cal() {
		if(income<=250000) 
			tax=0;
		else if(income<=500000) 
			tax= (income-250000)*0.1;
		else if(income<=1000000)
			tax=30000 + ((income-500000)*0.2);
		else 
			tax=50000 + ((income - 1000000)*0.3);
	}
	public void display() {
		System.out.println("Pan NUmber\tName\tTax-Income\tTax");
		System.out.println(pan+ "\t\t" + name + "\t" + income + "\t" +tax );
	}
}


public class TaxableIncome {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee1 object=new Employee1();
		object.input();
		object.cal();
		object.display();
	}

}
