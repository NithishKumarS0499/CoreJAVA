package lilhoppr;
abstract class Shape{
	abstract public void calculateArea();
}
class Square extends Shape{
	private float side;
 Square(float side){
	this.side=side; 
 }
	@Override
	public void calculateArea() {
		
		System.out.println("Area of Square="+(side*side));
	}
	
}
class Rect extends Shape{
	private int length,breadth;
	Rect(int length,int breadth)
	{
		this.length=length;
		this.breadth=breadth;
	}
	@Override
	public void calculateArea() {
		// TODO Auto-generated method stub
		System.out.println("Area of Rectangle="+(length*breadth));
	}
	
}
public class AbstractAreaMain {

	public static void main(String[] args) {
		Shape mainobject;
		mainobject=new Square(3.5f);
		mainobject.calculateArea();
		mainobject=new Rect(6,4);
		mainobject.calculateArea();
		

	}

}
