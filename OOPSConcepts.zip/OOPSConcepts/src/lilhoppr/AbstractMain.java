package lilhoppr;
abstract class Person{
	public abstract void display();
	void salaryDisplay() {
		System.out.println("salaryDisplay");
	}
}
class Employee2 extends Person{

	@Override
	public void display() {
		// TODO Auto-generated method stub
		System.out.println("display method of abstract class person");
	}
	
}

public class AbstractMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Employee2 object=new Employee2();
object.display();
object.salaryDisplay();
	}

}
