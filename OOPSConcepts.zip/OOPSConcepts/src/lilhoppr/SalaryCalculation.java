package lilhoppr;

import java.util.Scanner;

public class SalaryCalculation {

	public static void main(String[] args) {
		int salary=0,shift=0, savings=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Salary:");
		salary=sc.nextInt();
		System.out.println("Enter no. of Shifts:");
		shift=sc.nextInt();
		if(salary>8000) {
			System.out.println("Salary too Large.");
			
		}
		else if(shift<0) {
			System.out.println("Shifts too Small.");
			
		}
		else {
			savings=((salary/100)*(20+30)+((salary*shift)/100)*2);
			System.out.println("The Savings amount is: "+savings);
					
		}
		sc.close();
	}

}
