package lilhoppr;
class Parent1 {
	private int i;
	public int j;
	int k;//default
private void method1() {
	System.out.println("Private method Display private data"+i);
}
void displayData() {
	 System.out.println("DisplayData method of parent class");
	 method1();
 }
}
class Child1 extends Parent1 {//for inheritance use the keyword extends
	void display() {
		//System.out.println("i="+i);
		System.out.println("j="+j);
		System.out.println("k="+k);
	}
	//overriding is a run time Polymorphisam
	public void displayData() {
		//function overriding hides the parent function in child class
		System.out.println("DisplayData function of child class");
		super.displayData();//super is used to call parent class overridden method
		//from child class
	}
	
}
public class MainClassInheritance2 {

	public static void main(String[] args) {
		Child1 object=new Child1();
		object.display();
		object.displayData();//

	}

}
