package lilhoppr;
abstract class Bank{
	 abstract public void rateofInterest();
}
class SBI extends Bank{

	@Override
	public void rateofInterest() {
		System.out.println("Rate of Interest in SBI is "+4.5f);
		
	}
	
}
class HDFC extends Bank{

	@Override
	public void rateofInterest() {
		System.out.println("Rate of Interest in HDFC is "+5);
		
	}
	
}
class ICICI extends Bank{

	@Override
	public void rateofInterest() {
		System.out.println("Rate of Interest in ICICI is "+5.5f);
		
	}
	
}
public class AbstractBankMain {

	public static void main(String[] args) {
		SBI sobject=new SBI();
		sobject.rateofInterest();
		HDFC hobject=new HDFC();
		hobject.rateofInterest();
		ICICI iobject=new ICICI();
		iobject.rateofInterest();
		
		//Another Method of creating object
		
		Bank mainobject;
		mainobject=new SBI();
		mainobject.rateofInterest();
		
		mainobject=new HDFC();
		mainobject.rateofInterest();
		
		mainobject=new ICICI();
		mainobject.rateofInterest();

	}

}
