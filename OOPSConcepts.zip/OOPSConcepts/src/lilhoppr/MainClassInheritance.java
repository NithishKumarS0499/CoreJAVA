package lilhoppr;

class Parent
{
	private int i;  //scope with in a class nobody can access data
	public int j;
	int k; //default
	private void method1() {
		System.out.println("Private method display private data "+i);
	}
	public void displayParent() {
		System.out.println("Display method of Parent class");
		method1();
	}}
class Child extends Parent{//for inheritance use keywords extends
	void display() {
		Parent pob=new Parent();
		//System.out.println("i="+pob.i); //private
		System.out.println("j="+pob.j);
		System.out.println("k="+pob.k);
	}
	
}



public class MainClassInheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Child cob=new Child();
		cob.display();
		cob.displayParent();
		
	}

}
