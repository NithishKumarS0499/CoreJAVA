package lilhoppr;

import java.util.Scanner;

class Employe{
    String empname;
     int empage;
     float empsalary;
     String empdept;  
    float annualsal;   

  void empInput(){
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter name");
       empname=sc.nextLine();
     System.out.println("Enter age");
      empage=sc.nextInt();
    System.out.println("Enter salary");
     empsalary=sc.nextFloat(); //ex : 40000
    
     System.out.println("Enter employee Department");
     sc.nextLine();
     empdept=sc.nextLine();

}

void empAnnualSalary(){
   annualsal=empsalary*12;
}

void empDeatails(){
 System.out.println("Employee Details");
  System.out.println("Name="+empname);
   System.out.println("Annual salary="+annualsal);
   System.out.println("Age="+empage);
   System.out.println("Department="+empdept);
}
}


public class EmployeeDetailsMain {
	public static void main(String[]arg) {
	 Employe eob=new Employe();
	 eob.empInput();
	 eob.empAnnualSalary();
	 eob.empDeatails();
     Employe eob1=new Employe();
    	 eob.empInput();
    	 eob.empAnnualSalary();
    	 eob.empDeatails();
     }
}
