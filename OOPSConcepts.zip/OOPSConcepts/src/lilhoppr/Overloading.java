package lilhoppr;
class Addition{
	public void add(int i, int j) {
		int s=i+j;
		System.out.println("Sum of the integer numbers= "+s);
		
	}
	public void add(float i, float j) {
		float s=i+j;
		System.out.println("Sum of the float numbers="+s);
	}
	public void add(double i, double j) {
		double s=i+j;
		System.out.println("Sum of the Double numbers="+s);
	}
}
public class Overloading {

	public static void main(String[] args) {
		Addition object=new Addition();
		object.add(3, 5);
		object.add(3.5f, 5.6f);
		object.add(45.64, 67.45);
	}

}
