package lilhoppr;
class Addition1{
	 static int i=1;
	 int j;
	 
	 Addition1(){
		 j=1;
	 }
	 void nonStaticMethod() {
		 i=i+1;
		 j=j+1;
			 System.out.println("static i ="+i);
		 System.out.println("Non static ="+j);
		 
	 }
	 
	 
	 static void staticMethod() {
		 i=i+1; //static method can access only static data
		 //j=j+1; //static method cannot access non static 
			 System.out.println("static i ="+i);
		// System.out.println("Non static ="+j);
	 }
	}

	class Subtratction extends Addition1{
		@Override
		void nonStaticMethod() { //non static method can be overridden
			super.nonStaticMethod();
		}
	   
		static void staticMethod() { //static method cannot override
		
			System.out.println("static method ");
		}
	}

public class StaticMethodNonStatic {

	public static void main(String[] args) {
        Addition1 aob=new Addition1();
        Addition1 aob1=new Addition1();
        aob.nonStaticMethod();
        aob1.nonStaticMethod();
        Addition1.staticMethod(); //static method can access using class


	}

}
