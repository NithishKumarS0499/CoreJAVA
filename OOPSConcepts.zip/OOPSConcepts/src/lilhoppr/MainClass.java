package lilhoppr;

import java.util.Scanner;
class Rectangle{
	//declare variable
	 //these variable are called member data
	 //instance variable
	  
	 int length,breadth,arearec;
	 
	 //member function or methods
	 void input() {
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter Length and Breadth of a rectangle:");
		 length=sc.nextInt();
		 breadth=sc.nextInt();
	 }
     void calculate() {
    	 arearec=length*breadth;
     }
     void display() {
    	 System.out.println("The Area of Rectangle of length "+length+"and breadth "+breadth+"= "+arearec);
     }
}
/*driver program
 Create an object your classes and you can call the method
 */
public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 System.out.println("You Are in Main Method");
 
 //create an object
 Rectangle rob=new Rectangle();
  rob.input();
  rob.calculate();
  rob.display();
  
	 }
}
	


