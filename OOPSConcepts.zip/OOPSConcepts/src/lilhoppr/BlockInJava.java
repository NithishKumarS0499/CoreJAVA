package lilhoppr;

public class BlockInJava {
static
{
	System.out.println("Static Block executes before main");
}
{
	System.out.println("Normal BLock Execution before constructor");
}
 BlockInJava(){
	System.out.println("Constructor Block Execution"); 
 }
	public static void main(String[] args) {
		
		System.out.println("Main Method");
		BlockInJava object=new BlockInJava();
	}

}
