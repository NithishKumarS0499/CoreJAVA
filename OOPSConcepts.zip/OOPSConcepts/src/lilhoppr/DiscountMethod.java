package lilhoppr;

import java.util.Scanner;

public class DiscountMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      float totalcost,costTopaid, discount;
      Scanner sc=new Scanner(System.in);
      System.out.println("Enter the Amount of Perchased:");
      totalcost=sc.nextFloat();
      
    	  if(totalcost<=5000) {
    		  discount=0;
    	  costTopaid=totalcost;}
    	  else if (totalcost>5000 && totalcost<=10000) {
    		  discount=(totalcost*10)/100;
    	   costTopaid=totalcost-discount;}
    	   else if (totalcost>10000 && totalcost<=15000) {
     		  discount=(totalcost*15)/100;
     	   costTopaid=totalcost-discount;}
     	  else { 
    		  discount=(totalcost*20)/100;
    	   costTopaid=totalcost-discount;
      }
    	  System.out.println(discount+" discount");
    	  System.out.println("The cost to be paid is: "+costTopaid);
    	  
	}

}
