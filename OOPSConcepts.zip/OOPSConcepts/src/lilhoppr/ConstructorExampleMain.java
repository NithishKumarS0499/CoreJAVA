package lilhoppr;

import java.util.Scanner;

class Student1{
	private int sid;
	private String sname;
	//initialize data using constructor with arg
	public Student1() {
		sid=0;
		sname=null;
	}
	Student1(int sid, String sname){
		this.sid=sid;
		this.sname=sname;
	}
	
	void studentDisplay() {
		System.out.println("Id="+sid);
		System.out.println("Name="+sname);
	}
	public void inputData() {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name");
		sname=sc.nextLine();
		System.out.println("Enter id");
		sid=sc.nextInt();
	}
}

public class ConstructorExampleMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student1 s1=new Student1(1,"Kiran"); //calls constructor
		Student1 s2=new Student1(2,"Manoj");
          s1.studentDisplay();
          s2.studentDisplay();
          
          Student1 s3=new Student1();
          s3.inputData();
          s3.studentDisplay();
	}
}

	


