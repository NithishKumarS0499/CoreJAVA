package lilhoppr;

	


public class ThisKeyword {
	int i;
	  ThisKeyword(){
	     System.out.println("No argument constructor");
	  }
		
	  ThisKeyword(int i){
		  this();
		  this.i=i;
		  System.out.println("One argument constructor()"+i);
		  
	  }
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThisKeyword ob=new ThisKeyword(3);
		

		
	}

}
