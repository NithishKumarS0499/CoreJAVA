package lilhoppr;
	class Student{
		int sid;
		String sname;
		float sfees;
//constructor is same name as class and it not have any return type
		Student(){
//constructor with no arg
	System.out.println("Constructor is called on creation of an object implicity");
	sid=1;
	sname="Jigar";
	sfees=6754.45f;
			
		}
		Student(int sid, String sname, float sfees){
//Constructor with arguments
			this.sid=sid;// this is an implicit object
			this.sname=sname;
			this.sfees=sfees;
			
		}
	}
public class ConstructorDemoMain {

	public static void main(String[] args) {
		Student sobject=new Student();//calls constructor
		Student sobject1=new Student(2,"Aishu",8764.3f);//calls constructor
		Student sobject2=new Student(3,"Venkatesh",7654.56f);
		
		System.out.println("studentId= "+sobject.sid);
		System.out.println("studentName="+sobject.sname);
		System.out.println("StudentFees="+sobject.sfees);
		
		System.out.println("studentId= "+sobject1.sid);
		System.out.println("studentName="+sobject1.sname);
		System.out.println("StudentFees="+sobject1.sfees);
		
		System.out.println("studentId= "+sobject2.sid);
		System.out.println("studentName="+sobject2.sname);
		System.out.println("StudentFees="+sobject2.sfees);
		
		
		

	}

}
