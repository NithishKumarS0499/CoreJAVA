package lilhoppr;

import java.util.Scanner;

class EmployeeEmployee{
	private int eid;//different
	private String ename;//different
	private static String cname;//same
	 static {
		 cname="EdubridgeIndia";
		 
	 }
	 public void inputEmployee() {
		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter Name");
		 ename=sc.nextLine();
		 System.out.println("Enter Id");
		 eid=sc.nextInt();
	 }
	 public void empdetails() {
		 System.out.println("Name="+ename);
		 System.out.println("EmpID="+eid);
		 System.out.println("CompanyName="+cname);
	 }
}
public class StaticVarialeMethodMain {

	public static void main(String[] args) {
	 EmployeeEmployee object[]=new EmployeeEmployee[3];
	 for(int i=0;i<object.length;i++) {
	 object[i]=new EmployeeEmployee();
	 object[i].inputEmployee();
	 }
	  
	 System.out.println("All Employee Details");
	 for(int i=0;i<object.length;i++) {
		 object[i].empdetails();
	 }
	 

	}

}
