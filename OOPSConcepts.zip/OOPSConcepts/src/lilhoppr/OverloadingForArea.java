package lilhoppr;

class AreaCalculation{
	public void Area(int side) {
		int areasq=side*side;
		System.out.println("Area of Square for given Side is "+side+" ="+areasq+"sq.units");
		
	}
	 public void Area(int l, int b) {
		 int arearec=l*b;
		 System.out.println("Area of Rectangle for length is "+l+" and breadth is "+b+" = "+arearec+"sq.units");
	 }
	 public void Area(float r) {
		 float areacir=3.14f*r*r;
		 System.out.println("Area of Circle for given Radius is "+r+" = "+areacir+"sq.units");
	 }
	 public void Area(float b, float h) {
		 float areatri=0.5f*b*h;
		 System.out.println("Area of Triangle for Base is "+b+" and height is "+h+" = "+areatri+"sq.units");
	 }
}
public class OverloadingForArea {

	public static void main(String[] args) {
		AreaCalculation object=new AreaCalculation();
		object.Area(6);
		object.Area(7, 4);
		object.Area(3.5f);
		object.Area(4.5f, 6.7f);

	}

}
