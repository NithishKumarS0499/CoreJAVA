package lilhoppr;

import java.util.Scanner;

class Area{
	int length,breadth;
	float side,radius,height,base,arearec,areasq,areacir,areatri;
	Scanner sc=new Scanner(System.in);
	 void input()
	 {
		 System.out.println("Enter the length:");
		 length=sc.nextInt();
		 System.out.println("Enter the breadth:");
		 breadth=sc.nextInt();
		 System.out.println("Enter the Side:");
		 side=sc.nextFloat();
		 System.out.println("Enter the Radius:");
         radius=sc.nextFloat();	
		 System.out.println("Enter the Height:");
		 height=sc.nextFloat();
		 System.out.println("Enter the Base:");
		 base=sc.nextFloat();
	 }
	 void calAreaRectangle() {
		 arearec=length*breadth;
	 }
	 void calAreaSquare(){
		 areasq=side*side;
	 }
	 void calAreaCircle() {
		 areacir=3.14159f*radius*radius;
	 }
	 void calAreaTriangle() {
		 areatri=0.5f*base*height;
	 
	 }
	 void DisAreaRectangle() {
		 System.out.println("The Area of Rectangle for length= "+length+" breadth= "+breadth+" is "+arearec);
	 }
	 void DisAreaSquare() {
		 System.out.println("The Area of Square if Side= "+side+" Then Area= "+areasq);
	 }
	 void DisAreaCircle() {
		 System.out.println("The Area of Circle for Radius= "+radius+" is "+areacir);
	 }
	 void DisAreaTriangle() {
		 System.out.println("The Area of Triangle for Base="+base+" and Height="+height+" is "+areatri);
	 }
}
public class AreaOfFigures {

	public static void main(String[] args) {
		System.out.println("Area Of Figures:");
		Area object=new Area();
		object.input();
		object.calAreaRectangle();
		object.calAreaSquare();
		object.calAreaCircle();
		object.calAreaTriangle();
		object.DisAreaRectangle();
		object.DisAreaSquare();
		object.DisAreaCircle();
		object.DisAreaTriangle();
		
	}

}
