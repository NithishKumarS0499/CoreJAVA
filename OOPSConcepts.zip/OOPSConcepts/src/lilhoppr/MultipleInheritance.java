//Multiple inheritance in java Through Interface
package lilhoppr;
interface A{
    void method1();
}
interface B{
   void method2();
}

interface C extends A,B{
    void method3();//implicitly we have m1() and m2() 
}

class MyClass1 implements C{
      public void method1(){
           System.out.println("method1");
    }
public void method2(){
           System.out.println("method2");
    }

public void method3(){
           System.out.println("method3");
    }
}


public class MultipleInheritance {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	     MyClass1  object=new MyClass1();
         object.method1();
        object.method2();
         object.method3();

	}

}
