package lilhoppr;

interface MyInterface{
	int i=10;
	void method1();
	void method2();
	
}
 abstract class MyClass implements MyInterface{

	@Override
	public void method1() {
		System.out.println("Method1 "+i);
		
	}}
class Example extends MyClass{

	@Override
	public void method2() {
		System.out.println("Method2 "+i);
	}
	
}

	/*@Override
	public void method2() {
		//i=i+1; cannot change the value ,we can use it
		System.out.println("Method2 "+i);
		
	}*/
	



public class InterfaceMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Example object=new Example();
		object.method1();
		object.method2();
	}
	}


