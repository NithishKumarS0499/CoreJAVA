package lilhoppr;

import java.util.Scanner;

class RemoveVowel{

	private String st1;
	private String st2="";
	
	public void input()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the sentence");
		st1=sc.nextLine();
		sc.close();
	}
	public void removeVowelFunction()
	{
		for(int i=0;i<st1.length();i++)
		{
			char ch=st1.charAt(i);
			if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u')
			{
				st2=st2+"";
			}
			else
			{
				st2=st2+st1.charAt(i);
			}
		}
		System.out.println("String after removing vowel:"+st2);}
		
		public void  reverseAfterRemoveVowel() {
			for(int i=st2.length()-1;i>=0;i--) {
			System.out.print(st2.charAt(i));
			}
			
		}
	}



public class RemovingVowelMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		RemoveVowel object=new RemoveVowel();
		object.input();
		object.removeVowelFunction();
		object.reverseAfterRemoveVowel();
	}

}
