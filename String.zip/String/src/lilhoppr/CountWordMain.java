package lilhoppr;

import java.util.Scanner;

class WordCount{
	private String sentnce;
	private int  count;
	
	public void inputString() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Sentence:");
		sentnce=sc.nextLine();
	}
	public void countWordFunction() {
		for(int i=0;i<sentnce.length();i++) {
			char ch=sentnce.charAt(i);
			if(ch==' ') {
				count++;
			}
		}
		System.out.println("No of Words= "+(count+1));
	}
}
public class CountWordMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WordCount object=new WordCount();
		object.inputString();
		object.countWordFunction();

		
	}

}
