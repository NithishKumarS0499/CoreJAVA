package lilhoppr;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

class Validation{
	private String uname;
	private String upass;
	
	public void inputData() throws IOException  {
		InputStreamReader is =new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(is);
		//readLine(), read()
		//readLinr()->String
		//read()->ascii value
		
		System.out.println("Enter User Nmae:");
		uname=br.readLine();
		System.out.println("Enter Password:");
		upass=br.readLine();}
				
		public void userValidate() { 
			
			if(uname.equals("admin") && (upass.equals("admin123"))){
				//equalsIgnoreCase
				System.out.println("Username and password is valid");
			}
			else {
				System.out.println("Invalid user");
			}
		
	}}

public class StringFunction {

	public static void main(String[] args) throws IOException {
		
			
		Validation ob=new Validation();
		ob.inputData();
		ob.userValidate();


	}
		

	}


