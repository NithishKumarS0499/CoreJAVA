package lilhoppr;

import java.util.Scanner;

public class NoOfVowelsAndConsonants {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the String: ");
		s=sc.nextLine();
		int vowelcount=0,conscount=0;
		s=s.toLowerCase();
		
	for(int i=0;i<s.length();i++) {
		char ch=s.charAt(i);
		if(ch=='a' || ch=='e' || ch=='i' ||  ch=='o' || ch=='u'	) {
			vowelcount++;
		}
		else {
			conscount++;
		}
	}
	System.out.println("No of Vowels = "+vowelcount);
	System.out.println("No 0f Consonants= "+conscount);
	
	}

}
