package lilhoppr;

public class CapacityStringFunction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s= "Hello! Welcome to Heaven Gudalur";
		StringBuffer sb=new StringBuffer();
		int n=sb.capacity();
		System.out.println("Default capacity= "+n);
		StringBuffer sb1=new StringBuffer(s);
		int n1=sb1.capacity();
		System.out.println("Capacity of the String= "+n1);

	}

}
