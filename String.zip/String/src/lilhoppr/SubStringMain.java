package lilhoppr;

import java.util.Scanner;

public class SubStringMain {

	public static void main(String[] args) {
		String str ="Mahatama Karamchand Gandhi";
		  //System.out.println(str.indexOf('M'));
		  //System.out.println(str.indexOf('K'));
		System.out.print(str.charAt(0));
		System.out.print(".");
		System.out.print(str.charAt(9));
		System.out.print(".");
		System.out.println(str.substring(20));

		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Sentence");
		String s1=sc.nextLine();
		System.out.print(s1.charAt(0)+".");
		for(int i=0;i<s1.length();i++) {
			char ch=s1.charAt(i);
			if(ch==' ') {
				System.out.print(s1.charAt(i+1)+".");
			break;
			}
		
		}
		int last=s1.lastIndexOf(' ');
		System.out.println(s1.substring(last+1));
		
		
		
		System.out.println("Enter the Sentence for Initial Letter to be print");
		String s2=sc.nextLine();
		System.out.print(s2.charAt(0)+".");
		for(int i=0;i<s2.length();i++) {
			char ch=s2.charAt(i);
			if(ch==' ') {
				System.out.print(s2.charAt(i+1)+".");
			break;
			}
		
		}
		int las=s2.lastIndexOf(' ');
		System.out.print(s2.charAt(las+1));
		}	

	}


