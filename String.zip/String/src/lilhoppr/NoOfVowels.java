package lilhoppr;

public class NoOfVowels {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s= "edubridge";
		int count=0;
		System.out.println("No of charater="+s.length());
		System.out.println("To get a character at particular position"+s.charAt(6));
		
	for(int i=0;i<s.length();i++) {
		char ch=s.charAt(i);
		if(ch=='a' || ch=='e' || ch=='i' ||  ch=='o' || ch=='u') {
			count++;
		}
	}
	System.out.println("No of Vowels ="+count);
	
	
	
	
	//Print the given String in reverse order
	//output = egdirbude;
	
	for(int j=s.length()-1;j>=0;j--) {
		System.out.print(s.charAt(j));
	}
	}

}
