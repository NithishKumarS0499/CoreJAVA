package lilhoppr;

public class DeleteStringMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Edubridge Indias Leaning Center";
		StringBuffer sobject=new StringBuffer(s);
		System.out.println("String Before Delete: "+sobject);
		sobject.delete(17, 31);
		sobject.deleteCharAt(15);
		System.out.println("Sting After Delete: "+sobject);
	}

}
