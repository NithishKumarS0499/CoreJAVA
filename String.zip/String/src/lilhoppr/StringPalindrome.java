package lilhoppr;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class StringPalindrome {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		String ch;
		String rev="";
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Enter the Word:");
		ch=br.readLine();
		
		for(int i=ch.length()-1;i>=0;i--) {
			rev=rev+ch.charAt(i);
			}
		if(ch.equals(rev)) {
			System.out.println("The given String is palindrome");}
		else {
			System.out.println("The given String is not a Palindrome");
		}
		
	
		
		
	}}


