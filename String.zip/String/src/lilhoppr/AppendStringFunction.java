package lilhoppr;

public class AppendStringFunction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Edubridge";
		StringBuffer sobject=new StringBuffer(s);
		System.out.println("String Before Append: "+sobject);
		sobject.append(" India ");
		System.out.println("String After Append: "+sobject);
	}

}
