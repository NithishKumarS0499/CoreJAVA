package lilhoppr;

public class InsertMethod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Edubridge India pvt ltd";
		StringBuffer sobject=new StringBuffer(s);
		System.out.println("String Before Inserting: "+sobject);
		sobject.insert(10, "Learning Center ");
		sobject.insert(39, ",Trichy.");
		System.out.println("String After Inserting: "+sobject);
		

	}

	
}
