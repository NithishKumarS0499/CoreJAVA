package lilhoppr;

public class ReplaceFunction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 String s="My Name is Nidhish";
 //replace all occurrences of char
 String rep=s.replace('d', 't');
 System.out.println(rep);
 String reps=s.replace("Nidhish", "Jigar");
 System.out.println(reps);
 
 System.out.println(s);
	StringBuffer sb=new StringBuffer(s); //thread safe (
	sb.reverse();
	System.out.println(sb);
	StringBuilder sbuild=new StringBuilder(s);
	System.out.println(sbuild.reverse());
	
	sbuild.delete(2, 6);
	System.out.println(sbuild);

			

	}

}
