package lilhoppr;
import java.io.BufferedReader;

import java.io.IOException;
import java.io.InputStreamReader;

class Student{
	private int sid;
	private String sname;
	private float sfees;
	
	public void inputStudent() throws IOException {
		/*InputStreamReader is=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(is);
		*/
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		System.out.println("Enter student id"); //"9"
		sid=Integer.parseInt(br.readLine());
		System.out.println("Enter name");
		sname=br.readLine();
		System.out.println("Enter fees");
		sfees=Float.parseFloat(br.readLine());
		
	}
	public void displayStudent() {
		System.out.println("Name="+sname);
		System.out.println("Student id="+sid);
		System.out.println("Student fees="+sfees);
	}
	
}

public class BufferReaderToReadData {

	public static void main(String[] args) throws IOException {
		Student sob=new Student();
		sob.inputStudent();
        sob.displayStudent();


	}

}
